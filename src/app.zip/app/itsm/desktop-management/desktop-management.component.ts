import { Component } from '@angular/core';

@Component({
  selector: 'app-desktop-management',
  templateUrl: './desktop-management.component.html',
  styleUrls: ['./desktop-management.component.css']
})
export class DesktopManagementComponent {

}
