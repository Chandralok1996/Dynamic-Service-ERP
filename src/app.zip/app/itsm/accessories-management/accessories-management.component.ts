import { Component } from '@angular/core';

@Component({
  selector: 'app-accessories-management',
  templateUrl: './accessories-management.component.html',
  styleUrls: ['./accessories-management.component.css']
})
export class AccessoriesManagementComponent {

}
