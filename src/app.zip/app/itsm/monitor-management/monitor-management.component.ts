import { Component } from '@angular/core';

@Component({
  selector: 'app-monitor-management',
  templateUrl: './monitor-management.component.html',
  styleUrls: ['./monitor-management.component.css']
})
export class MonitorManagementComponent {

}
