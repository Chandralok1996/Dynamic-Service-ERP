import { Component } from '@angular/core';

@Component({
  selector: 'app-history-management',
  templateUrl: './history-management.component.html',
  styleUrls: ['./history-management.component.css']
})
export class HistoryManagementComponent {

}
