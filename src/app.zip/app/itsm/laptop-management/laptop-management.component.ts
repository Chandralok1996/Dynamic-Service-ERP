import { Component } from '@angular/core';

@Component({
  selector: 'app-laptop-management',
  templateUrl: './laptop-management.component.html',
  styleUrls: ['./laptop-management.component.css']
})
export class LaptopManagementComponent {

}
