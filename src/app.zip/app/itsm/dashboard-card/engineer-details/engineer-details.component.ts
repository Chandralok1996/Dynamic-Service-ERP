import { Component } from '@angular/core';

@Component({
  selector: 'app-engineer-details',
  templateUrl: './engineer-details.component.html',
  styleUrls: ['./engineer-details.component.css']
})
export class EngineerDetailsComponent {

}
