import { Component } from '@angular/core';

@Component({
  selector: 'app-proj-report',
  templateUrl: './proj-report.component.html',
  styleUrls: ['./proj-report.component.css']
})
export class ProjReportComponent {

}
