import { Component } from '@angular/core';

@Component({
  selector: 'app-engineer-call-details',
  templateUrl: './engineer-call-details.component.html',
  styleUrls: ['./engineer-call-details.component.css']
})
export class EngineerCallDetailsComponent {

}
