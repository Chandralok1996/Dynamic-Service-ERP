import { Component } from '@angular/core';

@Component({
  selector: 'app-eng-view',
  templateUrl: './eng-view.component.html',
  styleUrls: ['./eng-view.component.css']
})
export class EngViewComponent {

}
